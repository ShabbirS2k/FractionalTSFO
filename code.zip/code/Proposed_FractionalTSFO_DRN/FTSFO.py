import random,math
import numpy as np

def Algm():
    def generate(n, m, l, u):   #Generated solution
        data = []
        for i in range(n):
            tem = []
            for j in range(m):
                tem.append(random.uniform(l, u))
            data.append(tem)
        return data

    N, M, lb, ub = 10, 5, 1, 5
    g, max = 0, 100

    soln = generate(N, M, lb, ub)

    def fitness(soln):
        F = []
        for i in range(len(soln)):
            F.append(random.random())
        return F

    def spiral_foraging(X,Xbest,tmax):
        a=10
        Xi=[]
        b=random.uniform(0,1)
        r = random.uniform(0, 1)
        for i in range(len(X)):
            for j in range(len(X[i])):
                t=j
                A, epsilon = 10, 10
                Alpha1=a+(1-a)*(t/tmax)
                Alpha2=(1-a)-(1-a)*(t/tmax)
                Beta=np.exp(np.cos(2*np.pi*b))
                AP = A * (1 - (2 * tmax * epsilon))
                Xi.append((1/r-(Alpha1*Beta)+Alpha2)*(Xbest[j]*Alpha1*(1+Beta)-(X[i][j]-AP)*(Alpha1*Beta-Alpha2))+(Alpha1*X[i][j])+(1/2)*X[i][j]+(1/6)*(1-Alpha1)*X[i][j]+(1/24)*Alpha1*(1-Alpha1)*(2-Alpha1)*X[i][j])  # Update equation

        return Xi
    def tuna_forgaging(Xi,tmax):
        N_Xi=[]
        p1,p2,a=5,8,10
        Xrand=[]

        for i in range(len(Xi)):
            t=i
            Alpha1 = a + (1 - a) * (t / tmax)
            Alpha2 = (1 - a) - (1 - a) * (t / tmax)
            Xrand.append(random.uniform(p1,p2))
            N_Xi.append(Alpha1*(Xrand[i]-Xi[i]+Alpha2*Xi[i]))
        return N_Xi

    def Parabolic_foraging(Xbest,Xi,tmax):
        N_Xi=[]
        TF=random.uniform(1,-1)
        rand=random.uniform(0,1)
        for i in range(len(Xbest)):
            t=i
            p=(1-(t/tmax))**(t/tmax)
            if rand <0.5:
                N_Xi.append(Xbest[i]+rand*(Xbest[i]-Xi[i])+TF*np.square(p)*(Xbest[i]-Xi[i]))
            else:
                N_Xi.append(TF*np.square(p)*Xi[i])
        return N_Xi
    while g<max:
        Fit=fitness(soln)
        bst = np.argmax(Fit)
        Xbest=soln[bst]
        Xi=spiral_foraging(soln,Xbest,max)
        N_Xi=tuna_forgaging(Xi,max)
        upd_equ=Parabolic_foraging(Xbest,N_Xi,max)

        g += 1



    return abs(np.max(upd_equ))

