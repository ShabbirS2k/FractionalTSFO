import numpy as np

def key_matrix(data,B):
    k, l = data.shape
    w = len(data)
    r = data.shape[1]

    X=[]

    if 1<=k<=w:

        if 1 <= l <= r:

            for i in range(len(data)):
                temp=[]
                for j in range(len(data[i])):
                    Rk=np.sum(data[i][j])
                    temp.append(Rk)
                X.append(temp)

    #------------Cumulative Key Matrix--------
    L=[]
    XT=np.transpose(X)

    for ii in range(len(X)):
        tem=[]
        for jj in range(len(X[ii])):

            tem.append(B[ii][jj]*X[ii][jj])
        L.append(tem)

    J=[]
    for i in range(len(L)):
        temp=[]
        for j in range(len(L[i])):
            temp.append(np.sum(L[i][j]))
        J.append(temp)


    return X,J



