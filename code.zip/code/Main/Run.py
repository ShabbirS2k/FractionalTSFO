import pandas as pd
import numpy as np
import Data_Acquisation
import CPDM
import CU_CPDM
import Key_matrix
import Privacy_preservation
import Proposed_FractionalTSFO_DRN.DRN


def callmain(dts,ls):
    ACC,TPR,TNR=[],[],[]
    Data=pd.read_csv('Dataset/'+dts+'.csv',header=None)  # Load the dataset
    Data=np.array(Data)
    Data,Label=Data_Acquisation.read_data(Data)
    #----PU Coefficient Matrix-------
    cpd_matrix=CPDM.polarized_data(Data)  # Circular polarized Data Matrix

    cu_cpd_matrix=CU_CPDM.CU_Circular_Polarization(cpd_matrix) #Cumulative circular polarized Data Matrix


    X,J=Key_matrix.key_matrix(cu_cpd_matrix,cpd_matrix)

    ppd_matrix=Privacy_preservation.PPDM(Data,X,J)   #  Privacy Preserved Data Matrix

    PP_Data=Privacy_preservation.Extraction_Original_data(ppd_matrix,J) # Privacy preserved data


    #---------------------Proposed_FractionalTSFO_DRN----------------
    Proposed_FractionalTSFO_DRN.DRN.classify(PP_Data, Label, ls, ACC, TPR, TNR)

    return ACC,TPR,TNR



