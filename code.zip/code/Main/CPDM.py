import TSFO



def polarized_data(Data):
    CPDM_=[]


    for i in range(len(Data)):
        #print("i:",i)
        temp=[]
        for j in range(len(Data[i])):

            CS= int(Data[i][j]) ^ TSFO.Algm()
            temp.append(CS)

        CPDM_.append(temp)

    return CPDM_




