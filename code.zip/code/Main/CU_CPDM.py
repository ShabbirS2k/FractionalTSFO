import pandas as pd
import numpy as np




def CU_Circular_Polarization(Data):
    D=[]

    for i in range(len(Data)):
        temp=[]
        for j in range(len(Data[i])):
            temp.append(np.sum(Data[i][j]))
        D.append(temp)


    return D


