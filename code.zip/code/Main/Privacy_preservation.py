

def PPDM(G,X,J):

    GT =[]
    for i in range(len(X)):
        temp=[]
        for j in range(len(X[i])):

            temp.append(int(G[i][j])^X[i][j])
        GT.append(temp)


    #--------- Privacy Preserverd Data Matrix --------
    G_=[]

    for i in range(len(GT)):
        temp=[]
        for j in range(len(GT[i])):
            temp.append(GT[i][j]/J[i][j])
        G_.append(temp)

    return G_




def Extraction_Original_data(G_,J):


    GT_=[]

    for i in range(len(G_)):
        temp=[]
        for j in range(len(G_[i])):
            temp.append(G_[i][j]*J[i][j])
        GT_.append(temp)


    #------------------- Retrived database--------------
    G__=[]
    for i in range(len(GT_)):
        tem=[]
        for j in range(len(GT_[i])):
            tem.append(int(GT_[i][j])^J[i][j])
        G__.append(tem)


    return GT_

