import pandas as pd
import numpy as np


def read_data(data):
    Data=[]
    k,l=data.shape
    r=len(data)
    s=data.shape[1]

    if 1<=k<=r:
        if 1<=l<=s:
            Data.append(data)

    df = pd.DataFrame(data)

    df = df.replace(to_replace='?', value='1')

    Data = np.array(df)
    Data = Data.astype('float')
    Data=np.array(Data)
    Label=df.iloc[:,-1]
    Label=np.array(Label)

    return Data,Label
